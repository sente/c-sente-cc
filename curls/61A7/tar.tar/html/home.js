var log = console.log.bind(console);

enhance();

function enhance() {
    log('enhance():');

    lectureIEUsers();

    try { $('#nav').onePageNav(); } catch(e) {

         log('onepagenav() threw error ' + e);
    }


    $('.step.1').html('Customize your badge.');
        $('#sitename, #langchoice, #colorchoice').removeAttr('disabled'); // Undegrade to become functional.
        $('.pref').on('change', updateSnippet);
        $('option.lang[value="contribute"]').attr('title', // Set up the #t9n_info "link"
            'So far we have no other translations.  If you\'re multilingual and have 10 minutes to spare, then please consider contributing one.  Click for more information.'
        ).css('cursor',
            'pointer'
        ); // Apparently effectual on firefox.  The actual hook to make it function as a hashlink is done in the updateSnippet() CB.

        log('step 1 enhanced.');

    $('.step.2').html('Grab the resulting HTML snippet, and put it on your webpages.');
        updateSnippet();
        $('#snippet').change(function() {
          demo_snippet = $('#snippet').val().replace(/\?lang=/, '?cache=byebye&lang=');
          $('#result').html(demo_snippet);
        });

        log('step 2 enhanced.');

    $('.step.3').html('Your visitors will automatically be notified of any major developments in Julian\'s case and provided with action alerts.');
    $('.step.4').html('????');
    $('.step.5').html('Liberation 4 Julian!');

    $('#repo-embed').repo({ user: 'ADLWalrus', name: 'ADL' });

    $('forkit-curtain').css({position: 'absolute', bottom: 0, left: 0});


}


function lectureIEUsers() {
      log('LIU():');
      if(!-[1,]) if(confirm("You're apparently using some incarnation of Microsoft's Internet Explorer.  For the sake of your own sanity, and that of every other web developer around the world, please use a different browser.  Click OK to download the one I personally recommend, and you're guaranteed to never look back.  If you happen to be some kind of a self-hating masochist, then feel free to click the button labeled Cancel to continue in your misery and most likely incorrect experience of this webpage.")) window.location = 'http://getchromium.org/';
}

function updateSnippet () {
    
    log('updateSnippet() fired.');
    if ($('#langchoice').val() === 'contribute') {
        $.scrollTo('#contrib_t9n', 750);
        $('#langchoice').val('en');     // Revert to the default.
    }

  var adl_home = 'http://adl.sdf.org',
	  sitename = $('#sitename').val() || 'This site',
	  langchoice = $('#langchoice').val(),
	  colorchoice = $('#colorchoice').val();

  var the_snippet = '<a id="adl_badgelink" title="'+ sitename +' is a proud member of the Assange Defense League.  Enable JS for richer functionality, or click for details." href="'+adl_home+'">' +
                      '<img src="'+adl_home+'/badge/'+ colorchoice +'" alt="{\\FREE JULIAN ASSANGE!/}">' +
                      '<script src="'+adl_home+'/adl.cgi?lang='     + encodeURIComponent( langchoice ) + '">' + // Basically language is less likely to vary and so it won't negate all caching.
                                                      '{' + 
                                                          '"sitename": "' + encodeURIComponent( sitename ) + '"' +
                                                      '}' + // sitename will presumably vary for every site so we'll just get the JSON.
                      '<'+'/sc'+'ript>' +
                      '<iframe src="'+adl_home+'" style="display: none;"></iframe>' + 
                    '</a>'; // Some notes:
                                  // The iframe's for privacy so that snoops can't know whether or not the link was actually clicked.
                                  // Language is done as a GET, because it's unlikely to vary too much between different embeddings,
                                  // and even less likely to do so between different site that a single surfer would visit, and so it
                                  // won't affect most caching, whereas sitename will presumably vary for each site that deploys the 
                                  // badge, and so it must be done as JSON in the <script>'s innerHTML and then parsed clientside later.
                                  // Also, language being done serverside will help performance because I think it'll be a simple switch
                                  // without much sanitizing required and then only needed langpacks will be sent.
    

  log('the_snippet:' + the_snippet);
  $('#snippet').val(the_snippet).change();
        
  $('#snippet').attr('title', "Click to select, and press ^C to copy.");

  $('#snippet').on('click.selectall', function(){
     this.focus();
     this.select();
     $(this).off('click.selectall');
  });

}
