from collections import namedtuple

import stat
import pickle
import simplejson
import time
import fnmatch
from stat import ST_MODE,S_ISDIR,S_ISREG,S_ISLNK,ST_SIZE
import os


def build_trie_from_stdout(file_object):
    """parse a file containing lines of the form:
        $SIZE $PATH
        123 /some/path
        482 /some/other/path
     and create a Trie"""
    trie = Trie()

    for line in file_object.readlines():
        _size,_path = line.strip().split('\t')
        if _path.startswith('/'):
            _path = _path[1:]
        _size = int(_size)
        trie.insert(_path.split('/'), size=_size)

    return trie


def build_trie(fileObj):
    """parse a file containing a newline-separated list of words into
    a prefix tree"""

    trie = Trie()

    for word in fileObj.readlines():
        trie.insert(word.upper().strip())

    return trie


class Trie:
    """a trie structure for incremental word searching"""

    def __init__(self, name = "ROOT"):
        self.name = name
        self.children = {}
        self.size = 0

    def insert(self, path, size=0):
        """add a word to the trie"""

        if path == []:
            self.size = size
            return

        cur_dir, the_rest = path[0], path[1:]

        if not self.children.has_key(cur_dir):
            self.children[cur_dir] = Trie(name=cur_dir)

        self.children[cur_dir].insert(the_rest, size=size)


    def get_name(self):
        return self.name

    def get_children(self):
        return self.children

    def __getitem__(self,name):
        return self.children[name]

    def display_trie(self):
        return self.children.__repr__()

    def findstr(self,path):
        if path.startswith('/'):
            path = path[1:]

        if path.endswith('/'):
            path = path[:-1]

        return self.find(path.split('/'))

    def find(self, word):
        """search for a word in the trie"""

        print 'self.find(%s)' % word

        if word == []:
            print "word == []"
            return self

        letter, the_rest = word[0], word[1:]

        if not self.children.has_key(letter):
            return None

        return self.children[letter].find(the_rest)





if __name__ == '__main__':

    t = build_trie_from_stdout(open('tests/gildeddays.stdout'))


