def walklevel(some_dir, level=1):
    some_dir = some_dir.rstrip(os.path.sep)
    assert os.path.isdir(some_dir)
    num_sep = len([x for x in some_dir if x == os.path.sep])
    for root, dirs, files in os.walk(some_dir):
        yield root, dirs, files
        num_sep_this = len([x for x in root if x == os.path.sep])
        if num_sep + level <= num_sep_this:
            del dirs[:]


def walk_level(some_dir,maxdepth=0,group_directories=0):
    level=maxdepth
    if maxdepth == 0:
        level=999

    for root,dirs,files in walklevel(some_dir, level):
        rootsize=os.stat(root)[ST_SIZE]
        for f in files:
            try:
                fn = os.path.join(root, f)
                ss=os.stat(fn)
                rootsize+=ss[ST_SIZE]
                if not group_directories:
                    yield (ss[ST_SIZE], fn)
            except:
#                print "fail..%s" % fn
                pass
        if group_directories:
            yield (rootsize,root)



def walker(trie):
    total = trie.size
    for child_key in trie.children:
        child = trie.children[child_key]
        total += child.size
        total += walker(child)
    return total


def walk_children(t):
    res = {}
    for key, child in t.children.items():
#        if key != "":
        res[key] = walk_children(child)
#        if res[key] == {}:
#            del res[key]
    return res

def walk_trie(t, depth = 1):

    res = {}
    res['name'] = t.get_name()
    res['size'] = walker(t)

    if depth < 1:
        return res

    if t.children:
        res['children'] = []

    for k,v in t.children.items():
        if v.size == 0:
            res['children'].append(walk_trie(v, depth=depth-1))

    if 'children' in res and res['children'] == []:
        del res['children']

    if 'children' in res:
        del res['size']

    return res


