import trie


from trie import *
from helpers import *

t = build_trie_from_stdout(open('tests/trie.stdout'))


#open('cur.json','w').write(simplejson.dumps(walk_trie(t,depth=3)))
#open('../d3/examples/data/fullwalk.json','w').write(simplejson.dumps(walk_trie(t,depth=4)))
#
#walk_trie(t,depth=2)
#walk_trie(t,depth=11)







